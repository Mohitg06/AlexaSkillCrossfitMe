module.exports = {
    "RECIPE_EN_US" : {
        "me": "Yes , it is  defintely for you",
        "crossfitme": "What can I help you with",
        "karen": "Wal-Ball 150 shots for time ",
        "cindy": "5 pull ups, 10 push ups and 15 squats,As many rounds as possible in 20 min",
        "jackie": "1000 meter row,Thruster 45 lbs for 50 reps, pull ups  for 30 reps for time ",
        "nancy": "5 rounds for time , 400 meter run , 15 reps of overhead squat 95 lb ",
        "helen": "3 rounds for time; 400 meter run, 1.5 pood Kettlebell swing  for 21 reps, pull-ups 12 reps ",
        "information":" you can go on to https://www.crossfit.com/ and check it out.",
        "diane": "21-15-9 reps for time, Deadlift 225 lbs, Handstand push-ups ",
        "warmup": "Stretch, do body weight squats, 200 meter run ",
        "box": "Check reviews online for a crossfit box, go for dropins , get a feel of it.",
        "diet": "Crossfit recommends paleo diet.",
        "start": "Then you might get hurt and we don't want you to get hurt ",
        "sign ": "Most Crossfit boxes offer introductory classes ",
        "price": "Most of the Crossfit boxes have flexible payment options, depending upon the box.",
        "enrolled":"You have done an awesome job",
        "fact": " You will get insanely good at counting",
        "rx":"When a WOD is performed RX'd, that means the athlete performs all modalities using the prescribed weight and reps",
        "murph":"1 round for time  1 mile run, 100 pull ups, 200 push ups, 300 squats, 1 mile run",
        "grip":"Wrap your hand around the bar and grab as much of your thumb as you can with the first two fingers",
        "wod":"The WOD is the workout of the day. Each day a new WOD is posted to CrossFit.com, and it's part of a complete program designed to improve strength and conditioning. ",
        "crossfit": "CrossFit is a fitness regimen developed by Greg Glassman over several decades. Glassman, CrossFit's Founder and CEO, was the first person in history to define fitness in a meaningful, measurable way: increased work capacity across broad time and modal domains. He then created a program specifically designed to improve fitness and health."
	}

};